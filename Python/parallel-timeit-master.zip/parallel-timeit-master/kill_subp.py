import asyncio
import pandas as pd
import time
import os

commands_per_file = [{
    "file": file,
    "cortes": ["./mock_main.py -v aa -c {} -t 1 -i {}".format(c, file) for c in [0, 2, 6]]
} for file in os.listdir("./files")]


async def spawn(cmd):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE)
    stdout, _ = await proc.communicate()
    return stdout


async def run_command(cmd, ttl):
    """
        Dado um comando retorna tempo de execucao ou "ttl"
    """
    start = time.time()
    try:
        await asyncio.wait_for(spawn(cmd), timeout=ttl)
        delta = time.time() - start
        return delta
    except asyncio.TimeoutError:
        return "ttl"


async def main():
    for i in range(0, len(commands_per_file)):
        commands_per_file[i]["cortes"] = [asyncio.create_task(
            run_command(cmd, 0.5)) for cmd in commands_per_file[i]["cortes"]]

        commands_per_file[i]["cortes"] = [await task for task in commands_per_file[i]["cortes"]]

    print(commands_per_file)

asyncio.run(main())

df = pd.DataFrame(commands_per_file)
